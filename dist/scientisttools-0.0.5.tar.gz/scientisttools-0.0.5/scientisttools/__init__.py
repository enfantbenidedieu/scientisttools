# -*- coding: utf-8 -*-
from scientisttools.version import __version__

__name__ = "scientisttools"
__author__ = 'Duverier DJIFACK ZEBAZE'
__email__ = 'duverierdjifack@gmail.com'